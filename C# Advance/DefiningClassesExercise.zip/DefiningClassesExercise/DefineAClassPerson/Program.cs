﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Person person = new Person("a", 3);
            Person newOne = new Person();
        }
    }
}
