﻿using System;

namespace PartyReservationFilterModule
{
    class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
