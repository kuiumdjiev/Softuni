﻿namespace MatchingBrackets
{
    internal class stack<T>
    {
    }
}