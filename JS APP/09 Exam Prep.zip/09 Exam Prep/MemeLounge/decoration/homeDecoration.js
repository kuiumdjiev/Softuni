import { getItems } from "../hepers/get/get-items.js";
import { allItmesTemplate } from "../template/allItmesTemplate.js";
import { homeTemplate } from "../template/homeTemplate.js";
import { navTemplate } from "../template/navTemplate.js";


export async function homeDecoration(ctx, next) {
    let data =await getItems();
    ctx.home  =  homeTemplate(data);
    ctx.nav = navTemplate();
    
    next();
}