import {  getItem } from "../hepers/get/get-Item.js";
import { editTemplate } from "../template/editTemplate.js";

export async function editDecoration(ctx, next) {
    let id = ctx.params.id;
    let data =  await getItem(id)
    ctx.edit  = editTemplate(data);
    next();
}