import {  getMyItems } from "../hepers/get/get-myItems.js";
import { myItemsTemplate } from "../template/myItemsTemplate.js";

export async function myItemsDecoration(ctx, next) {
    let myItems=await getMyItems(sessionStorage.getItem('id'))
    ctx.myItems  = myItemsTemplate(myItems);
    next();
}