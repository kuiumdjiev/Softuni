import { html } from "../node_modules/lit-html/lit-html.js";

export let allItmesTemplate = (data) => html`
<!-- All Memes Page ( for Guests and Users )-->
<section id="meme-feed">
  <h1>All Memes</h1>
  <div id="memes">
${data.length == 0 ? noItemInDatabase() : data.map(x => singleTemplate(x))}
  </div>
</section>
`
export let noItemInDatabase = () => html`
  <!-- Display : If there are no memes in database -->
  <p class="no-memes">No memes in database.</p>
`
export let singleTemplate = (data) => html`
        <!-- Display : All memes in database ( If any ) -->
        <div class="meme">
          <div class="card">
            <div class="info">
              <p class="meme-title">${data.title}</p>
              <img class="meme-image" alt="meme-img" src="${data. imageUrl}">
            </div>
            <div id="data-buttons">
              <a class="button" href="/details/${data._id}">Details</a>
            </div>
          </div>
        </div>
`