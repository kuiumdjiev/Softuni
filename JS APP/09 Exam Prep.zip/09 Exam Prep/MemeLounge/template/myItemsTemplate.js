import { html } from "../node_modules/lit-html/lit-html.js";

export let myItemsTemplate = (data) => html`
<!-- Profile Page ( Only for logged users ) -->
<section id="user-profile-page" class="user-profile">
        <article class="user-info">
                <img id="user-avatar-url" alt="user-profile"
                        src="${sessionStorage.getItem('gender') === 'female' ? '/images/female.png' : '/images/male.png'}">
                <div class="user-content">
                        <p>Username: ${sessionStorage.getItem('username')}</p>
                        <p>Email: ${sessionStorage.getItem('email')}</p>
                        <p>My memes count: ${data.length}</p>
                </div>
        </article>
        <h1 id="user-listings-title">User Memes</h1>
        <div class="user-meme-listings">
        ${data.length == 0 ? noItemInDatabase() : data.map(x => singleTemplate(x))}

        </div>
</section>
`
export let noItemInDatabase = () => html`
<!-- Display : If user doesn't have own memes  -->
<p class="no-memes">No memes in database.</p>
`
export let singleTemplate = (data) => html`
<div class="user-meme">
        <p class="user-meme-title">${data.title}</p>
        <img class="userProfileImage" alt="meme-img" src="${data.imageUrl}">
        <a class="button" href="/details/${data._id}">Details</a>
</div>
`