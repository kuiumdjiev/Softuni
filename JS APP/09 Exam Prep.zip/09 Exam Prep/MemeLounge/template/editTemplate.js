import { createFormObject } from "../hepers/formatObject/formatObject.js";
import { putEdit } from "../hepers/put/put-edit.js";
import { html } from "../node_modules/lit-html/lit-html.js";

let edit = async e => {
    e.preventDefault();
    let formObject = createFormObject(e.target)
   let title=formObject.title;
   let description =formObject.description;
   let imageUrl= formObject.imageUrl;

    if (title==''||description==''||imageUrl=='') {
        alert('Please fill all fields.');
        return;
    }
    let body = {
       title,
       description,
       imageUrl
    };
    let id = document.getElementsByClassName('registerbtn button')[0].id;
    putEdit(body, id);
}
// 
export let editTemplate = (data) => html`
 <!-- Edit Meme Page ( Only for logged user and creator to this meme )-->
 <section id="edit-meme">
    <form @submit="${edit}" id="edit-form">
        <h1>Edit Meme</h1>
        <div class="container">
            <label for="title">Title</label>
            <input id="title" value="${data.title}" type="text" placeholder="Enter Title" name="title">
            <label for="description">Description</label>
            <textarea id="description" placeholder="Enter Description" name="description">${data.description}</textarea>
            <label for="imageUrl">Image Url</label>
            <input id="imageUrl" value="${data.imageUrl}" type="text" placeholder="Enter Meme ImageUrl" name="imageUrl">
            <input id="${data._id}" type="submit" class="registerbtn button" value="Edit Meme">
        </div>
    </form>
</section>
`