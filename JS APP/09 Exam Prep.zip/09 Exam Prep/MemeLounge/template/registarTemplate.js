import { createFormObject } from "../hepers/formatObject/formatObject.js";
import { postRegister } from "../hepers/post/post-registar.js";
import { html } from "../node_modules/lit-html/lit-html.js";

let registar = async e => {
    e.preventDefault();
    let formObject = createFormObject(e.target)
    let username = formObject.username;
    let email = formObject.email;
    let password = formObject.password;
    let repeatPass = formObject.repeatPass;
    let gender=formObject.gender

    if (email==''||password==''||repeatPass=='') {
        alert('Please fill all fields.');
        return;
    }
    if (password !== repeatPass) {
        alert('Password and repeat password must be equal')
        return;
    }

    let body = {
        email,
        username,
        password,
        gender
    };
    postRegister(body);
}

//
export let registarTemplate = () => html`
  <!-- Register Page ( Only for guest users ) -->
  <section id="register">
            <form @submit="${registar}" id="register-form">
                <div class="container">
                    <h1>Register</h1>
                    <label for="username">Username</label>
                    <input id="username" type="text" placeholder="Enter Username" name="username">
                    <label for="email">Email</label>
                    <input id="email" type="text" placeholder="Enter Email" name="email">
                    <label for="password">Password</label>
                    <input id="password" type="password" placeholder="Enter Password" name="password">
                    <label for="repeatPass">Repeat Password</label>
                    <input id="repeatPass" type="password" placeholder="Repeat Password" name="repeatPass">
                    <div class="gender">
                        <input type="radio" name="gender" id="female" value="female">
                        <label for="female">Female</label>
                        <input type="radio" name="gender" id="male" value="male" checked>
                        <label for="male">Male</label>
                    </div>
                    <input type="submit" class="registerbtn button" value="Register">
                    <div class="container signin">
                        <p>Already have an account?<a href="/login">Sign in</a>.</p>
                    </div>
                </div>
            </form>
        </section>
`