import { getLogout } from "../hepers/get/get-logout.js";
import { html } from "../node_modules/lit-html/lit-html.js";

let logout = async e => {
    e.preventDefault();
   getLogout();
}

export let navTemplate = () => html`
<a href="/allItems">All Memes</a>
${sessionStorage.getItem('token') ? admin() : guest()}
`
//
export let admin = () => html`
<!-- Logged users -->
<div class="user">
    <a href="/create">Create Meme</a>
    <div class="profile">
        <span>Welcome, ${sessionStorage.getItem('email')}</span>
        <a href="myItems">My Profile</a>
        <a @click="${logout}" href="javascript:void(0)">Logout</a>
    </div>
</div>
`
export let guest = () => html`
<!-- Guest users -->
<div class="guest">
    <div class="profile">
        <a href="/login">Login</a>
        <a href="/registar">Register</a>
    </div>
    <a class="active" href="/">Home Page</a>
</div>

`