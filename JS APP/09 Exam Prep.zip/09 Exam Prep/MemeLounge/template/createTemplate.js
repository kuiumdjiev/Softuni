import { html } from "../node_modules/lit-html/lit-html.js";
import { createFormObject } from "../hepers/formatObject/formatObject.js";
import { postCreate } from "../hepers/post/post-create.js";

let create = async e => {
    e.preventDefault();
    let formObject = createFormObject(e.target)
    let title = formObject.title;
    let description = formObject.description;
    let imageUrl = formObject.imageUrl;

    if (title == '' || description == '' || imageUrl == '') {
        alert('Please fill all fields.');
        return;
    }
    let body = {
        title,
        description,
        imageUrl
    };
    postCreate(body);
}
//
export let createTemplate = () => html` 
    <!-- Create Meme Page ( Only for logged users ) -->
    <section id="create-meme">
        <form @submit="${create}" id="create-form">
            <div class="container">
                <h1>Create Meme</h1>
                <label for="title">Title</label>
                <input id="title" type="text" placeholder="Enter Title" name="title">
                <label for="description">Description</label>
                <textarea id="description" placeholder="Enter Description" name="description"></textarea>
                <label for="imageUrl">Meme Image</label>
                <input id="imageUrl" type="text" placeholder="Enter meme ImageUrl" name="imageUrl">
                <input type="submit" class="registerbtn button" value="Create Meme">
            </div>
        </form>
    </section>
`