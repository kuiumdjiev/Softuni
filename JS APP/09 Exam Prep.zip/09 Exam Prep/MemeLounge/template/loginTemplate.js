import { postLogin } from "../hepers/post/post-login.js";
import { createFormObject } from "../hepers/formatObject/formatObject.js";
import { html } from "../node_modules/lit-html/lit-html.js";

let login = async e => {
    e.preventDefault();
    let formObject = createFormObject(e.target)
    let email = formObject.email;
    let password = formObject.password;
    if (email == '' || password == '') {
        alert('Please fill all fields.');
        return;
    }

    let body = {
        email,
        password
    };
    postLogin(body);
}
//
export let loginTemplate = () => html`

        <!-- Login Page ( Only for guest users ) -->
        <section id="login">
            <form @submit="${login}" id="login-form">
                <div class="container">
                    <h1>Login</h1>
                    <label for="email">Email</label>
                    <input id="email" placeholder="Enter Email" name="email" type="text">
                    <label for="password">Password</label>
                    <input id="password" type="password" placeholder="Enter Password" name="password">
                    <input type="submit" class="registerbtn button" value="Login">
                    <div class="container signin">
                        <p>Dont have an account?<a href="/registar">Sign up</a>.</p>
                    </div>
                </div>
            </form>
        </section>
`