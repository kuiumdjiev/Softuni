import page from '../../node_modules/page/page.mjs'

export async function putEdit(body, id) {
    let url = `http://localhost:3030/data/memes/${id}`



    let method = {
        headers: {
            'X-Authorization':sessionStorage.getItem('token'),
            'Content-Type': 'aplication/json'
        },
        method: 'Put',
        body: JSON.stringify(body)
    }

    await fetch(url, method);



    
    page.redirect(`/details/${id}`);

}