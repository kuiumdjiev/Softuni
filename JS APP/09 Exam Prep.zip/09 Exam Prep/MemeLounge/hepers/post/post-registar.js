import page from '../../node_modules/page/page.mjs'

export async function postRegister(body) {
    let url = 'http://localhost:3030/users/register'



    let method = {
        headers: {
            'Content-Type': 'aplication/json'
        },
        method: 'Post',
        body: JSON.stringify(body)
    }

    try {
        let response = await fetch(url, method);
        let result = await response.json()


        //sessionStorage.setItem('id', result._id);
        //sessionStorage.setItem('token', result.accessToken);
        //sessionStorage.setItem('username', result.username);
        page.redirect('/');


    } catch (error) {
        alert(error);
        return
    }
}