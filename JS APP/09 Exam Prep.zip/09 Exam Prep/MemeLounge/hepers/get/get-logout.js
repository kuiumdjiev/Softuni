import page from '../../node_modules/page/page.mjs'

export async function getLogout() {
    let url = `http://localhost:3030/users/logout`
    let method = {
        headers: {
            'X-Authorization':sessionStorage.getItem('token'),
            'Content-Type': 'aplication/json'
        },
        method: 'Get'
    }
    sessionStorage.removeItem('id');
    sessionStorage.removeItem('token');
    sessionStorage.removeItem('username');
    let $fetch = await fetch(url, method);
    let body = await $fetch.json();
    console.log(body);
  
    page.redirect('/');

}