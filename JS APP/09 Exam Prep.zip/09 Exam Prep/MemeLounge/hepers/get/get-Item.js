export async function getItem(id) {
    let url = `http://localhost:3030/data/memes/${id}`
    let method = {
        headers: {
            'Content-Type': 'aplication/json'
        },
        method: 'Get',
    }
    let $fetch = await fetch(url, method);
    let body = await $fetch.json();
    return body;
}