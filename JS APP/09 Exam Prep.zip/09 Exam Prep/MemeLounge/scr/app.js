import { allItemsDecoration } from '../decoration/allItemsDecoration.js';
import { createDecoration } from '../decoration/createDecoration.js';
import { detailsDecoration } from '../decoration/detailsDecoration.js';
import { editDecoration } from '../decoration/editDecoration.js';
import { homeDecoration } from '../decoration/homeDecoration.js';
import { loginDecoration } from '../decoration/loginDecoration.js';
import {  myItemsDecoration } from '../decoration/myItemsDecoration.js';
import { registarDecoration } from '../decoration/registerDecoration.js';
import page from '../node_modules/page/page.mjs';
import { allItems } from '../page/allItems.js';
import { create } from '../page/create.js';
import { details } from '../page/details.js';
import { edit } from '../page/edit.js';
import { home } from '../page/home.js';
import { login } from '../page/login.js';
import { myItems } from '../page/myItems.js';
import { registar } from '../page/registar.js';



page('/index.html','/');
page('/',homeDecoration,home);
page('/registar',registarDecoration,registar);
page('/login',loginDecoration,login)
page('/allItems',allItemsDecoration,allItems)
page('/create',createDecoration,create)
page('/details/:id',detailsDecoration,details)
page('/edit/:id',editDecoration,edit)
page('/myItems',myItemsDecoration,myItems)
page.start();