import { render } from '../node_modules/lit-html/lit-html.js';

export function allItems(context) {
    render(context.AllItems,document.getElementsByTagName('main')[0]);
}