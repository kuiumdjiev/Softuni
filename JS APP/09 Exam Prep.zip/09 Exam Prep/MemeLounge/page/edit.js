import { render } from '../node_modules/lit-html/lit-html.js';

export function edit(context) {
    render(context.edit,document.getElementsByTagName('main')[0]);
}