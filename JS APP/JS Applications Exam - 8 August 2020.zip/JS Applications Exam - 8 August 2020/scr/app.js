import { allCarsDecoration } from '../decoration/allCars.js';
import { createDecoration } from '../decoration/createDecoration.js';
import { detailsDecoration } from '../decoration/detailsDecoration.js';
import { editDecoration } from '../decoration/editDecoration.js';
import { homeDecoration } from '../decoration/homeDecoration.js';
import { loginDecoration } from '../decoration/loginDecoration.js';
import { myCarsDecoration } from '../decoration/myCarsDecoration.js';
import { registarDecoration } from '../decoration/registerDecoration.js';
import page from '../node_modules/page/page.mjs';
import { allCars } from '../page/allCars.js';
import { create } from '../page/create.js';
import { details } from '../page/details.js';
import { edit } from '../page/edit.js';
import { home } from '../page/home.js';
import { login } from '../page/login.js';
import { myCars } from '../page/myCars.js';
import { registar } from '../page/registar.js';



page('/index.html','/');
page('/',homeDecoration,home);
page('/registar',registarDecoration,registar);
page('/login',loginDecoration,login)
page('/allCars',allCarsDecoration,allCars)
page('/create',createDecoration,create)
page('/details/:id',detailsDecoration,details)
page('/edit/:id',editDecoration,edit)
page('/myCars',myCarsDecoration,myCars)
page.start();