import { render } from '../node_modules/lit-html/lit-html.js';

export function myItems(context) {
    render(context.myItems,document.getElementsByTagName('main')[0]);
}