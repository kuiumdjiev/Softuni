import { render } from '../node_modules/lit-html/lit-html.js';

export function allCars(context) {
    render(context.allCars,document.getElementsByTagName('main')[0]);
}