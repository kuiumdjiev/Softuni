import { render } from '../node_modules/lit-html/lit-html.js';

export function myCars(context) {
    render(context.myCars,document.getElementsByTagName('main')[0]);
}