import { postLogin } from "../hepers/post/post-login.js";
import { createFormObject } from "../hepers/formatObject/formatObject.js";
import { html } from "../node_modules/lit-html/lit-html.js";

let login = async e => {
    e.preventDefault();
    let formObject = createFormObject(e.target)
 

    if () {
        alert('Please fill all fields.');
        return;
    }
    
    let body = {
       
    };
    postLogin(body);
}
//@submit="${login}" 
export let loginTemplate = () => html`
`