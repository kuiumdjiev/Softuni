import { html, nothing } from '../node_modules/lit-html/lit-html.js';

let del = async e => {
    e.preventDefault();

    deleteItem(e.target.id);
}

export let detailsTemplate = (data) => html`
`