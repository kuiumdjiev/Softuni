import { html } from "../node_modules/lit-html/lit-html.js";

export let myItemsTemplate = (data) => html`

        ${data.length == 0 ? noItemInDatabase() : data.map(x => singleTemplate(x))}

`
export let noItemInDatabase = () => html`
`
export let singleTemplate = (data) => html`

`