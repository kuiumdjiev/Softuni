import { html } from "../node_modules/lit-html/lit-html.js";
import { createFormObject } from "../hepers/formatObject/formatObject.js";
import { postCreate } from "../hepers/post/post-create.js";

let create = async e => {
    e.preventDefault();
    let formObject = createFormObject(e.target)
   

    if () {
        alert('Please fill all fields.');
        return;
    }
    let body = {
         
    };
    postCreate(body);
}
//@submit="${create}" 
export let createTemplate = () => html`   
`