import { createFormObject } from "../hepers/formatObject/formatObject.js";
import { putEdit } from "../hepers/put/put-edit.js";
import { html } from "../node_modules/lit-html/lit-html.js";

let edit = async e => {
    e.preventDefault();
    let formObject = createFormObject(e.target)
   

    if () {
        alert('Please fill all fields.');
        return;
    }
    let body = {
       
    };
    let id = document.getElementsByClassName('')[0].id;
    putEdit(body, id);
}
// @submit="${edit}"
export let editTemplate = (data) => html`
`