import { createFormObject } from "../hepers/formatObject/formatObject.js";
import { postRegister } from "../hepers/post/post-registar.js";
import { html } from "../node_modules/lit-html/lit-html.js";

let registar = async e => {
    e.preventDefault();
    let formObject = createFormObject(e.target)
    let username = formObject.username;
    let password = formObject.password;
    let repeatPass = formObject.repeatPass;

    if () {
        alert('Please fill all fields.');
        return;
    }
    if (password !== repeatPass) {
        alert('Password and repeat password must be equal')
        return;
    }

    let body = {
        
    };
    postRegister(body);
}

//@submit="${registar}"
export let registarTemplate = () => html`
`