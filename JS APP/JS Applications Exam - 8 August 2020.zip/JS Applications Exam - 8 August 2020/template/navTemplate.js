import { getLogout } from "../hepers/get/get-logout.js";
import { html } from "../node_modules/lit-html/lit-html.js";

let logout = async e => {
    e.preventDefault();
    getLogout();
}

export let navTemplate = () => html`

    ${sessionStorage.getItem('token') ? admin() : guest()}
 
`
//
export let admin = () => html`
<li class="nav-item">
    <a class="nav-link">Welcome, ${sessionStorage.getItem('email')}</a>
</li>
<li class="nav-item">
    <a class="nav-link" @click="${logout}" href="javascript:void(0)">Logout</a>
</li>
`
export let guest = () => html`
<li class="nav-item">
    <a class="nav-link" href="#">Login</a>
</li>
<li class="nav-item">
    <a class="nav-link" href="#">Register</a>
</li>
`