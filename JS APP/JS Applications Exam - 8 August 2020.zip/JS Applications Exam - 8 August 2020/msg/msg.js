import { html, render } from "../node_modules/lit-html/lit-html.js";

export function renderErr(msg){
    render(err(msg),document.getElementById('box')[0]);
}

export function renderSucc(){
    render(succ(),document.getElementById('box')[0]);
}

export let err = (msg) => html`
<section class="notifications" style="display: none;">
    <p class="notification-message" id="errorBox">${msg}</p>
</section>
`
export let succ = () => html`
<section class="notifications" style="display: none;background-color:rgba(1, 131, 29, 0.541);">
    <p class="notification-message" id="successBox">success</p>
</section>
`