import { getCar } from "../hepers/get/get-car.js";
import { editTemplate } from "../template/editTemplate.js";

export async function editDecoration(ctx, next) {
    let id = ctx.params.id;
    let data =  await getCar(id)
    ctx.edit  = editTemplate(data);
    next();
}