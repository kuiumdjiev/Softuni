import { getCar } from "../hepers/get/get-car.js";
import { detailsTemplate } from "../template/detailsTemplate.js";

export async function detailsDecoration(ctx, next) {
    let id = ctx.params.id;
    let details =  await getCar(id)
    ctx.details  = detailsTemplate(details);
    next();
}