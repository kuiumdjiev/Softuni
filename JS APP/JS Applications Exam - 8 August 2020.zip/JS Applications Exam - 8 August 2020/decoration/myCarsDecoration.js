import { getMyCars } from "../hepers/get/get-myCars.js";
import { myCarsTemplate } from "../template/myCarsTemplate.js";

export async function myCarsDecoration(ctx, next) {
    let myCars=await getMyCars(sessionStorage.getItem('id'))
    ctx.myCars  = myCarsTemplate(myCars);
    next();
}