import { getCars } from "../hepers/get/get-cars.js";
import { allCarsTemplate } from "../template/allCarsTemplate.js";


export async function allItemsDecoration(ctx, next) {
    let data =await AllItems();
    console.log(data);

    ctx.AllItemste  = allIte(data);    
    next();
}