import { getMyCars } from "../hepers/get/get-myCars.js";
import { myItemsTemplate } from "../template/myItemsTemplate.js";

export async function myCarsDecoration(ctx, next) {
    let myCars=await getMyCars(sessionStorage.getItem('id'))
    ctx.myItems  = myItemsTemplate(myCars);
    next();
}