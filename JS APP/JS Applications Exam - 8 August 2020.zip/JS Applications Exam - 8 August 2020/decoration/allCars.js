import { getCars } from "../hepers/get/get-cars.js";
import { allCarsTemplate } from "../template/allCarsTemplate.js";


export async function allCarsDecoration(ctx, next) {
    let data =await getCars();
    console.log(data);

    ctx.allCars  = allCarsTemplate(data);    
    next();
}