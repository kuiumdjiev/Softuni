export async function getMyItems(id) {
    let url = `http://localhost:3030/data/cars?where=_ownerId%3D%22${id}%22&sortBy=_createdOn%20desc`
    let method = {
        headers: {
            'Content-Type': 'aplication/json'
        },
        method: 'Get',
    }
    let $fetch = await fetch(url, method);
    let body = await $fetch.json();
    return body;
}