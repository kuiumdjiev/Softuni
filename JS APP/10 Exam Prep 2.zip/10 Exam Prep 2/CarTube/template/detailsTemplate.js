import { deleteItem } from '../hepers/del/del-Item.js';
import { html, nothing } from '../node_modules/lit-html/lit-html.js';

let del = async e => {
    e.preventDefault();

    deleteItem(e.target.id);
}

export let detailsTemplate = (data) => html`
<!-- Listing Details Page -->
<section id="listing-details">
    <h1>Details</h1>
    <div class="details-info">
        <img src="${data.imageUrl}">
        <hr>
        <ul class="listing-props">
            <li><span>Brand:</span>${data.brand}</li>
            <li><span>Model:</span>${data.model}</li>
            <li><span>Year:</span>${data.year}</li>
            <li><span>Price:</span>${data.price}$</li>
        </ul>

        <p class="description-para">${data.description}</p>

        ${sessionStorage.getItem('id')==data._ownerId ?admin(data):nothing}

    </div>
</section>
`
export let admin = (data) => html`
<div class="listings-buttons">
    <a href="/edit/${data._id}" class="button-list">Edit</a>
    <a id="${data._id}" @click="${del}" href="javascript:void(0)" class="button-list">Delete</a>
</div>`