import { createFormObject } from "../hepers/formatObject/formatObject.js";
import { putEdit } from "../hepers/put/put-edit.js";
import { html } from "../node_modules/lit-html/lit-html.js";

let edit = async e => {
    e.preventDefault();
    let formObject = createFormObject(e.target)
    let brand = formObject.brand;
    let model = formObject.model;
    let description = formObject.description;
    let year = formObject.year;
    let imageUrl = formObject.imageUrl;
    let price = formObject.price;


    if (brand == '' || model == '' || description == '' || year == '' || imageUrl == '' || price=='') {
        alert('Please fill all fields.');
        return;
    }

    if (isNaN(Number(price)) || Number(price) < 0 || isNaN(Number(year)) || Number(year) < 0) {
        alert('The values of year and price must be positive numbers.');
        return;
    }

    let body = {
        brand,
        model,
        description,
        year: Number(year),
        imageUrl,
        price: Number(price)
    };
    let id = document.getElementsByClassName('registerbtn')[0].id;
    putEdit(body, id);
}
// 
export let editTemplate = (data) => html`
  <!-- Edit Listing Page -->
  <section id="edit-listing">
            <div class="container">

                <form  @submit="${edit}" id="edit-form">
                    <h1>Edit Car Listing</h1>
                    <p>Please fill in this form to edit an listing.</p>
                    <hr>

                    <p>Car Brand</p>
                    <input type="text" value="${data.brand}" placeholder="Enter Car Brand" name="brand" >

                    <p>Car Model</p>
                    <input type="text" value="${data.model}" placeholder="Enter Car Model" name="model" >

                    <p>Description</p>
                    <input type="text" value="${data.description}" placeholder="Enter Description" name="description" >

                    <p>Car Year</p>
                    <input type="number" value="${data.year}" placeholder="Enter Car Year" name="year" >

                    <p>Car Image</p>
                    <input type="text" value="${data.imageUrl}" placeholder="Enter Car Image" name="imageUrl" >

                    <p>Car Price</p>
                    <input type="number" value="${data.price}" placeholder="Enter Car Price" name="price" >

                    <hr>
                    <input id="${data._id}" type="submit" class="registerbtn" value="Edit Listing">
                </form>
            </div>
        </section>
`