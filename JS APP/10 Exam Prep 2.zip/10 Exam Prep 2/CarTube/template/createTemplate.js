import { html } from "../node_modules/lit-html/lit-html.js";
import { createFormObject } from "../hepers/formatObject/formatObject.js";
import { postCreate } from "../hepers/post/post-create.js";

let create = async e => {
    e.preventDefault();
    let formObject = createFormObject(e.target)
    let brand = formObject.brand;
    let model = formObject.model;
    let description = formObject.description;
    let year = formObject.year;
    let imageUrl = formObject.imageUrl;
    let price = formObject.price;


    if (brand == '' || model == '' || description == '' || year == '' || imageUrl == '' || price=='') {
        alert('Please fill all fields.');
        return;
    }

    if (isNaN(Number(price)) || Number(price) < 0 || isNaN(Number(year)) || Number(year) < 0) {
        alert('The values of year and price must be positive numbers.');
        return;
    }

    let body = {
        brand,
        model,
        description,
        year: Number(year),
        imageUrl,
        price: Number(price)
    };
    postCreate(body);
}
//
export let createTemplate = () => html`
<!-- Create Listing Page -->
<section id="create-listing">
    <div class="container">
        <form @submit="${create}" id="create-form">
            <h1>Create Car Listing</h1>
            <p>Please fill in this form to create an listing.</p>
            <hr>

            <p>Car Brand</p>
            <input type="text" placeholder="Enter Car Brand" name="brand">

            <p>Car Model</p>
            <input type="text" placeholder="Enter Car Model" name="model">

            <p>Description</p>
            <input type="text" placeholder="Enter Description" name="description">

            <p>Car Year</p>
            <input type="number" placeholder="Enter Car Year" name="year">

            <p>Car Image</p>
            <input type="text" placeholder="Enter Car Image" name="imageUrl">

            <p>Car Price</p>
            <input type="number" placeholder="Enter Car Price" name="price">

            <hr>
            <input type="submit" class="registerbtn" value="Create Listing">
        </form>
    </div>
</section>
`