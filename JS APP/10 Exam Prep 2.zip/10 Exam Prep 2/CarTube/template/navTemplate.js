import { getLogout } from "../hepers/get/get-logout.js";
import { html } from "../node_modules/lit-html/lit-html.js";

let logout = async e => {
    e.preventDefault();
   getLogout();
}

export let navTemplate = () => html`
<a class="active" href="/">Home</a>
<a href="/allItems">All Listings</a>
<a href="#">By Year</a>
${sessionStorage.getItem('token') ? admin() : guest()}
 
`
//
export let admin = () => html`
<!-- Logged users -->
<div id="profile">
    <a>Welcome ${sessionStorage.getItem('username')}</a>
    <a href="/myItems">My Listings</a>
    <a href="/create">Create Listing</a>
    <a @click="${logout}" href="javascript:void(0)">Logout</a>
</div>
`
export let guest = () => html`

                <!-- Guest users -->
                <div id="guest">
                    <a href="/login">Login</a>
                    <a href="/registar">Register</a>
                </div>
`