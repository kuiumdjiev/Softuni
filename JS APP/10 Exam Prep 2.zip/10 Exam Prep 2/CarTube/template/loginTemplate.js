import { postLogin } from "../hepers/post/post-login.js";
import { createFormObject } from "../hepers/formatObject/formatObject.js";
import { html } from "../node_modules/lit-html/lit-html.js";

let login = async e => {
    e.preventDefault();
    let formObject = createFormObject(e.target)
    let username = formObject.username;
    let password = formObject.password;


    if (username == '' || password == '') {
        alert('Please fill all fields.');
        return;
    }

    let body = {
        username,
        password
    };
    postLogin(body);
}
//
export let loginTemplate = () => html`

    <!-- Login Page -->
    <section id="login">
        <div class="container">
            <form @submit="${login}" id="login-form" action="#" method="post">
                <h1>Login</h1>
                <p>Please enter your credentials.</p>
                <hr>
    
                <p>Username</p>
                <input placeholder="Enter Username" name="username" type="text">
    
                <p>Password</p>
                <input type="password" placeholder="Enter Password" name="password">
                <input type="submit" class="registerbtn" value="Login">
            </form>
            <div class="signin">
                <p>Dont have an account?
                    <a href="/registar">Sign up</a>.
                </p>
            </div>
        </div>
    </section>
`