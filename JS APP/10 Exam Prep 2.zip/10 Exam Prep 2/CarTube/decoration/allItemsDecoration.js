import { getItems } from "../hepers/get/get-items.js";
import { allItmesTemplate } from "../template/allItmesTemplate.js";


export async function allItemsDecoration(ctx, next) {
    let data =await getItems();
    console.log(data);

    ctx.AllItems  = allItmesTemplate(data);    
    next();
}