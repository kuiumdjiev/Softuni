﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using Bakery.Core.Contracts;
using Bakery.Models.BakedFoods;
using Bakery.Models.BakedFoods.Contracts;
using Bakery.Models.Drinks;
using Bakery.Models.Drinks.Contracts;
using Bakery.Models.Tables;
using Bakery.Models.Tables.Contracts;
using Bakery.Utilities.Messages;

namespace Bakery.Core
{
    public class Controller: IController
    {
        private readonly  ICollection<ITable> tables;
        private readonly ICollection<IBakedFood> bakedFoods;
        private readonly ICollection<IDrink> drinks;
        private decimal total;

        public Controller()
        {
            tables = new List<ITable>();
            bakedFoods = new List<IBakedFood>();
            drinks = new List<IDrink>();
            total = 0;
        }
        public string AddFood(string type, string name, decimal price)
        {
            IBakedFood bakedFood = null;
            switch (type)
            {
                case "Bread":
                    bakedFood = new Bread(name,price);
                    bakedFoods.Add(bakedFood);
                    return $"Added {name} ({bakedFood.GetType().Name}) to the menu";
                 
                   
                case "Cake":
                    bakedFood = new Cake(name, price);
                    bakedFoods.Add(bakedFood);
                    return $"Added {name} ({bakedFood.GetType().Name}) to the menu";
                    
              
            }

            return "";
        }

        public string AddDrink(string type, string name, int portion, string brand)
        {
            IDrink drink = null;
            switch (type)
            {
                case "Tea":
                    drink = new Tea(name, portion, brand);
                    drinks.Add(drink);
                    return $"Added {name} ({brand}) to the drink menu";


                case "Water":

                    drink = new Water(name, portion, brand);
                    drinks.Add(drink);
                    return $"Added {name} ({brand}) to the drink menu";
            }
            return "";
        }

        public string AddTable(string type, int tableNumber, int capacity)
        {
            ITable table = null;
            switch (type)
            {
                case "InsideTable":
                    table = new InsideTable(tableNumber, capacity);
                    break;
                case "OutsideTable":
                    table = new OutsideTable(tableNumber, capacity);
                    break;
            }
            tables.Add(table);
            return $"Added table number {tableNumber} in the bakery";
        }

        public string ReserveTable(int numberOfPeople)
        {
            ITable table = tables.FirstOrDefault(x => x.IsReserved == false && x.Capacity >= numberOfPeople);
            if (table==null)
            {
                return $"No available table for {numberOfPeople} people";
            }
            table.Reserve(numberOfPeople);
            return $"Table {table.TableNumber} has been reserved for {numberOfPeople} people";
        }

        public string OrderFood(int tableNumber, string foodName)
        {
            ITable tabel = tables.FirstOrDefault(x => x.TableNumber == tableNumber);
            IBakedFood bakedFood = bakedFoods.FirstOrDefault(x => x.Name == foodName);
            if (tabel==null)
            {
                return $"Could not find table {tableNumber}";
            }

            if (bakedFood==null)
            {
                return $"No {foodName} in the menu";
            }
            tabel.OrderFood(bakedFood);
            return $"Table {tableNumber} ordered {foodName}";
            
        }

        public string OrderDrink(int tableNumber, string drinkName, string drinkBrand)
        {
            ITable tabel = tables.FirstOrDefault(x => x.TableNumber == tableNumber);
            IDrink bakedFood = drinks.FirstOrDefault(x => x.Brand == drinkBrand&&x.Brand==drinkBrand);
            if (tabel == null)
            {
                return $"Could not find table {tableNumber}";
            }

            if (bakedFood == null)
            {
                return $"There is no {drinkName} {drinkBrand} available";
            }
            tabel.OrderDrink(bakedFood);
            return $"Table {tableNumber} ordered {drinkName} {drinkBrand}";
        }

        public string LeaveTable(int tableNumber)
        {
            ITable table = tables.FirstOrDefault(x => x.TableNumber == tableNumber);
            StringBuilder sb = new StringBuilder();
            total += table.GetBill();
            sb.AppendLine($"Table: {tableNumber}");
            sb.AppendLine($"Bill: {table.GetBill()}");
            table.Clear();
            return sb.ToString().TrimEnd();
        }

        public string GetFreeTablesInfo()
        {
            StringBuilder sb = new StringBuilder();
            var rTables = tables.Where(x => x.IsReserved == false).ToList();
            foreach (var table in tables)
            {
                
                    sb.AppendLine(table.GetFreeTableInfo());
                  
            }

            return sb.ToString().TrimEnd();
        }

        public string GetTotalIncome()
        {
            decimal sumDrink = drinks.Sum(x => x.Price);
            decimal sumFood = bakedFoods.Sum(x => x.Price);

            return string.Format(OutputMessages.TotalIncome, total);
        }
    }
}