using NUnit.Framework;
using System;
using System.Collections.Generic;

namespace BankSafe.Tests
{
    public class BankVaultTests
    {
        [SetUp]
        public void Setup()
        {
           
        }

        [Test]
        //Cell doesn't exists!
        public void CellDoesntExists()
        {
            BankVault bankVault = new BankVault();
            Item item = new Item("Pesho", "122402");

          Assert.That(()=>  bankVault.AddItem("F4",item),Throws.ArgumentException.With.Message.EqualTo("Cell doesn't exists!"));
        }
        //Allredy takeyn
        [Test]
        public void CellIsAlreadyTaken()

        {
            BankVault bankVault = new BankVault();
            Item item = new Item("Pesho", "122402");
            Item item2 = new Item("Pesho", "122402");
            bankVault.AddItem("A1", item);
            Assert.That(() => bankVault.AddItem("A1", item2), Throws.ArgumentException.With.Message.EqualTo("Cell is already taken!"));
            // throw new ArgumentException("Cell is already taken!");

        }

        [Test]
        //Item is already in cell!
        public void ItemIsAlreadyInCCell()
        {
            BankVault bankVault = new BankVault();
            Item item = new Item("Pesho", "122402");
           
            bankVault.AddItem("A1", item);
            Assert.That(() => bankVault.AddItem("A2", item), Throws.InvalidOperationException.With.Message.EqualTo("Item is already in cell!"));
        }
        [Test]
        //Item is already in cell!
        public void Sucs()
        {
            BankVault bankVault = new BankVault();
            Item item = new Item("Pesho", "122402");

          
            Assert.That(bankVault.AddItem("A1", item),Is.EqualTo($"Item:{item.ItemId} saved successfully!"));
        }

        [Test]
        //Cell doesn't exists!
        public void CellDoesntExistsRemove()
        {
            BankVault bankVault = new BankVault();
            Item item = new Item("Pesho", "122402");

           
            Assert.That(() => bankVault.RemoveItem("A5", item), Throws.InvalidOperationException.With.Message.EqualTo("Cell doesn't exists!"));
        }
        [Test]
        //"Item in that cell doesn't exists!"
        public void ItemDosentExsistRemove()
        {
            BankVault bankVault = new BankVault();
            Item item = new Item("Pesho", "122402");


            Assert.That(() => bankVault.RemoveItem("A1", item), Throws.ArgumentException.With.Message.EqualTo("Item in that cell doesn't exists!"));
        }

        [Test]
        // $"Remove item:{item.ItemId} successfully!"
        public void RemoveItem()
        {
            BankVault bankVault = new BankVault();
            Item item = new Item("Pesho", "122402");
            bankVault.AddItem("A1", item);

            Assert.That(bankVault.RemoveItem("A1",item), Is.EqualTo($"Remove item:{item.ItemId} successfully!"));
        }
        [Test]
        // $"Remove item:{item.ItemId} successfully!"
        public void Equal()
        {
            BankVault bankVault = new BankVault();
            Item item = new Item("Pesho", "122402");
            bankVault.AddItem("A1", item);

            Assert.That(item.ItemId, Is.EqualTo("122402"));
           
        }

        [Test]
        public void Owner()
        {
            BankVault bankVault = new BankVault();
            Item item = new Item("Pesho", "122402");
            bankVault.AddItem("A1", item);
            Assert.That(item.Owner, Is.EqualTo("Pesho"));
        }

        [Test]
        public void Dict()
        {

            BankVault bankVault = new BankVault();
            Item item = new Item("Pesho", "122402");
            
            Dictionary<string, Item> vaultCells = new Dictionary<string, Item>()
            {

                {"A1", null},
                {"A2", null},
                {"A3", null},
                {"A4", null},
                {"B1", null},
                {"B2", null},
                {"B3", null},
                {"B4", null},
                {"C1", null},
                {"C2", null},
                {"C3", null},
                {"C4", null},

            };
            Assert.That(vaultCells ,Is.EqualTo(bankVault.VaultCells));
        }
    
    }
}