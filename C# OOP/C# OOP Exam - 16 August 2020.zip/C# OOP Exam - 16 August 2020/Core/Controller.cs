﻿using System;
using System.Collections.Generic;
using System.Linq;
using OnlineShop.Common.Constants;
using OnlineShop.Models.Products;
using OnlineShop.Models.Products.Components;
using OnlineShop.Models.Products.Computers;
using OnlineShop.Models.Products.Peripherals;

namespace OnlineShop.Core
{
    public class Controller : IController
    {
        private List<IPeripheral> peripherals;
        private List<IComputer> computers;
        private List<IComponent> components;
        public Controller()
        {
            peripherals = new List<IPeripheral>();
            computers = new List<IComputer>();
            components = new List<IComponent>();
        }

        public string AddComputer(string computerType, int id, string manufacturer, string model, decimal price)
        {
            IComputer comp = computers.FirstOrDefault(x => x.Id == id);
            if (comp != null)
            {
                throw new ArgumentException("Computer with this id already exists.");
            }

            switch (computerType)
            {
                case "DesktopComputer":
                    comp = new DesktopComputer(id, manufacturer, model, price);
                    break;
                case "Laptop":
                    comp = new Laptop(id, manufacturer, model, price);
                    break;
                default: throw new ArgumentException("Computer type is invalid.");
            }

            computers.Add(comp);
            return $"Computer with id {id} added successfully.";
        }

        public string AddPeripheral(int computerId, int id, string peripheralType, string manufacturer, string model,
            decimal price, double overallPerformance, string connectionType)
        {
            Comp(computerId);
            if (peripherals.Any(x => x.Id == id))
            {
                throw new ArgumentException("Peripheral with this id already exists.");
            }

            IComputer comp = computers.FirstOrDefault(x => x.Id == computerId);
            IPeripheral peripheral = null;
            switch (peripheralType)
            {
                case "Headset":
                    peripheral = new Headset(id, manufacturer, model, price, overallPerformance, connectionType);
                    break;
                case "Keyboard":
                    peripheral = new Keyboard(id, manufacturer, model, price, overallPerformance, connectionType);
                    break;
                case "Monitor":
                    peripheral = new Monitor(id, manufacturer, model, price, overallPerformance, connectionType);
                    break;
                case "Mouse":
                    peripheral = new Mouse(id, manufacturer, model, price, overallPerformance, connectionType);
                    break;
                default: throw new ArgumentException("Peripheral type is invalid.");
            }

            peripherals.Add(peripheral);
            comp.AddPeripheral(peripheral);
            return $"Peripheral {peripheralType} with id {id} added successfully in computer with id {computerId}.";
        }

        public string RemovePeripheral(string peripheralType, int computerId)
        {
            Comp(computerId);
            Comp(computerId);
            IPeripheral peripheral = peripherals.FirstOrDefault(c => c.GetType().Name == peripheralType);
            IComputer computer = computers.First(c => c.Id == computerId);
            if (peripheral == null)
            {
                throw new ArgumentException(string.Format(ExceptionMessages.NotExistingPeripheral, peripheralType,
                    computer.GetType().Name, computerId));
            }

            peripherals.Remove(peripheral);
            computer.RemoveComponent(peripheralType);
            return string.Format(SuccessMessages.RemovedPeripheral, peripheralType, peripheral.Id);
        }

        public string AddComponent(int computerId, int id, string componentType, string manufacturer, string model,
            decimal price, double overallPerformance, int generation)
        {
            Comp(computerId);
            if (components.Any(x => x.Id == id))
            {
                throw new ArgumentException("Component with this id already exists.");
            }

            IComputer comp = computers.FirstOrDefault(x => x.Id == computerId);
            IComponent component = null;
            switch (componentType)
            {
                case "CentralProcessingUnit":
                    component = new CentralProcessingUnit(id, manufacturer, model, price, overallPerformance,
                        generation);
                    break;
                case "Motherboard":
                    component = new Motherboard(id, manufacturer, model, price, overallPerformance, generation);
                    break;
                case "PowerSupply":
                    component = new PowerSupply(id, manufacturer, model, price, overallPerformance, generation);
                    break;
                case "RandomAccessMemory":
                    component = new RandomAccessMemory(id, manufacturer, model, price, overallPerformance, generation);
                    break;
                case "SolidStateDrive":
                    component = new SolidStateDrive(id, manufacturer, model, price, overallPerformance, generation);
                    break;
                case "VideoCard":
                    component = new VideoCard(id, manufacturer, model, price, overallPerformance, generation);
                    break;
                default: throw new ArgumentException("Component type is invalid.");
            }

            components.Add(component);
            comp.AddComponent(component);
            return $"Component {componentType} with id {id} added successfully in computer with id {computerId}.";
        }

        public string RemoveComponent(string componentType, int computerId)
        {
            Comp(computerId);
            IComponent component = components.FirstOrDefault(c => c.GetType().Name == componentType);
            IComputer computer = computers.First(c => c.Id == computerId);
            if (component == null)
            {
                throw new ArgumentException(string.Format(ExceptionMessages.NotExistingComponent, componentType,
                    computer.GetType().Name, computerId));
            }

            components.Remove(component);
            computer.RemoveComponent(componentType);
            return string.Format(SuccessMessages.RemovedComponent, componentType, component.Id);
        }

        public string BuyComputer(int id)
        {
            Comp(id);
            IComputer comp = computers.FirstOrDefault(x => x.Id == id);
            computers.Remove(comp);
            return comp.ToString();
        }

        public string BuyBest(decimal budget)
        {
            IComputer computer = computers
                .OrderByDescending(c => c.OverallPerformance)
                .FirstOrDefault(c => c.Price <= budget);

            if (computer == null)
            {
                throw new ArgumentException(string.Format(ExceptionMessages.CanNotBuyComputer, budget));
            }

            computers.Remove(computer);

            return computer.ToString();
        }

        public string GetComputerData(int id)
        {
            Comp(id);
            return computers.First(c => c.Id == id).ToString();
        }

        private void Comp(int id)
        {
            if (!computers.Any(x => x.Id == id))
            {
                throw new ArgumentException("Computer with this id does not exist.");
            }
        }
    }
}