﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OnlineShop.Models.Products.Components;
using OnlineShop.Models.Products.Peripherals;

namespace OnlineShop.Models.Products.Computers
{
    public abstract class Computer:Product,IComputer
    {
        private List<IComponent> components;
        private List<IPeripheral> peripherals;
        public Computer(int id, string manufacturer, string model, decimal price, double overallPerformance) : base(id, manufacturer, model, price, overallPerformance)
        {
            components = new List<IComponent>();
            peripherals = new List<IPeripheral>();
        }

        public IReadOnlyCollection<IComponent> Components => components.AsReadOnly();
        public IReadOnlyCollection<IPeripheral> Peripherals => peripherals.AsReadOnly();
        public virtual double OverallPerformance => Performance();
        public virtual decimal Price => AllPrice();
        public void AddComponent(IComponent component)
        {
            if (Components.Any(x=>x.GetType().Name==component.GetType().Name))
            {
                throw new ArgumentException(string.Format(Common.Constants.ExceptionMessages.ExistingComponent,component.GetType().Name,this.GetType().Name,component.Id));
            }
            components.Add(component);
        }

        public IComponent RemoveComponent(string componentType)
        {
            if (components.Count==0||Components.Any(x=>x.GetType().Name==componentType))
            {
            throw new ArgumentException(string.Format(Common.Constants.ExceptionMessages.NotExistingComponent,componentType,this.GetType().Name,this.Id));
            }

            IComponent com = Components.FirstOrDefault(x => x.GetType().Name == componentType);
            components.Remove(com);
            return com;
        }

        public void AddPeripheral(IPeripheral peripheral)
        {
            if (Peripherals.Any(x => x.GetType().Name == peripherals.GetType().Name))
            {
                throw new ArgumentException(string.Format(Common.Constants.ExceptionMessages.ExistingPeripheral, peripheral.GetType().Name, this.GetType().Name, peripheral.Id));
            }
            peripherals.Add(peripheral);
        }

        public IPeripheral RemovePeripheral(string peripheralType)
        {
            if (peripherals.Count == 0 || peripheralType.Any(x => x.GetType().Name == peripheralType))
            {
                throw new ArgumentException(string.Format(Common.Constants.ExceptionMessages.NotExistingPeripheral, peripheralType, this.GetType().Name, this.Id));
            }

            IPeripheral com = Peripherals.FirstOrDefault(x => x.GetType().Name == peripheralType);
            peripherals.Remove(com);
            return com;
        }

        private double Performance()
        {
            if (Components.Count==0)
            {
                return OverallPerformance;
            }

            return OverallPerformance + Components.Average(c => c.OverallPerformance);
        }

        private decimal AllPrice()
        {
            return Price + Components.Sum(s => s.Price) + Peripherals.Sum(f => f.Price);
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Overall Performance: {OverallPerformance}. Price: {Price} - {this.GetType().Name}: {Manufacturer} {Model} (Id: {Id})");
            sb.AppendLine($" Components ({Components.Count}):");
            foreach (var component in Components)
            {
                sb.AppendLine($"  {component}");
            }

            sb.AppendLine($" Peripherals ({Peripherals.Count}); Average Overall Performance ({peripherals.Average(p => p.OverallPerformance):F2}):");
            return sb.ToString().TrimEnd();
        }
    }
}