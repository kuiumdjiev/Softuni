﻿using System;

namespace OnlineShop.Models.Products
{
    public abstract class Product : IProduct
    {
        private int id;
        private string manufacturer;
        private string model;
        private decimal price;
        private double overallPerformance;

        protected Product(int id, string manufacturer, string model, decimal price, double overallPerformance)
        {
            this.id = id;
            this.manufacturer = manufacturer;
            this.model = model;
            this.price = price;
            this.overallPerformance = overallPerformance;
        }

        public int Id
        {
            get => id;
            private set
            {
                if (value <= 0)
                {
                    throw new ArgumentException(Common.Constants.ExceptionMessages.InvalidProductId);
                }

                id = value;
            }
        }

        public string Manufacturer
        {
            get => manufacturer;
            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException(Common.Constants.ExceptionMessages.InvalidManufacturer);
                }

                manufacturer = value;
            }
        }

        public string Model
        {
            get => model;
            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException(Common.Constants.ExceptionMessages.InvalidModel);
                }

                model = value;
            }
        }

        public decimal Price
        {
            get=>price;
            private set
            {
                if (value<=0)
                {
                    throw new ArgumentException(Common.Constants.ExceptionMessages.InvalidPrice);

                }

                price = value;
            }
        }

        public double OverallPerformance
        {
            get=>overallPerformance;
            private set
            {
                if (value<=0)
                {
                    throw new ArgumentException(Common.Constants.ExceptionMessages.InvalidOverallPerformance);

                }

                overallPerformance = value;
            }
        }

        public override string ToString()
        {
            return $"Overall Performance: {OverallPerformance}. Price: {Price:F2} - {this.GetType().Name}: {Manufacturer} {Model} (Id: {id})";
        }
    }
}