﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WarCroft.Entities.Characters.Contracts;
using WarCroft.Entities.Inventory;
using WarCroft.Entities.Items;

namespace WarCroft.Core
{
	public class WarController
	{
		private List<Character> characters;
		private List<IBag> bags;
		private List<Item> items;
		public WarController()
		{
			characters = new List<Character>();
			bags = new List<IBag>();
			items = new List<Item>();
		}

		public string JoinParty(string[] args)
		{
			//•	characterType – string
			//	•	name – string
			Character character = null;
			string characterType = args[0];
			string name = args[1];
			switch (characterType)
			{
				case "Priest":
					character = new Priest(name);
					break;
				case "Warrior":
					character = new Warrior(name);
					break;
				default:
					throw new ArgumentException($"Invalid character type \"{characterType}\"!");
			}
characters.Add(character);
			return $"{name} joined the party!";
		}

		public string AddItemToPool(string[] args)
		{
			//•	itemName – string
			string itemName = args[0];
			Item item = null;
			switch (itemName)
			{
				case "HealthPotion":
					item = new HealthPotion();
					break;
				case "FirePotion" :
					item = new FirePotion();
					break;
				default:
					throw new ArgumentException($"Invalid item \"{itemName}\"!");
			}
items.Add(item);
			return $"{itemName} added to pool.";
		}

		public string PickUpItem(string[] args)
		{
			//•	characterName – string
			string charecterName = args[0];
			Character character = characters.FirstOrDefault(x => x.Name == charecterName);
			if (character==null)
			{
				throw new ArgumentException($"Character {charecterName} not found!");
			}

			if (items.Count==0)
			{
				throw new InvalidOperationException("No items left in pool!");
			}

			Item item = items.LastOrDefault();
			character.Bag.AddItem(item);
			items.Remove(item);
			return $"{charecterName} picked up {item.GetType().Name}!";
		}

		public string UseItem(string[] args)
		{
			//•	characterName – a string
//			•	itemName – string
			string characterName = args[0];
			string itemName = args[1];
			Character character = characters.FirstOrDefault(x => x.Name == characterName);
			if (character==null)
			{
				throw new ArgumentException($"Character {characterName} not found!");
			}

			Item item = character.Bag.GetItem(itemName);
			character.UseItem(item);
			return $"{character.Name} used {itemName}.";
		}

		public string GetStats()
		{
			var ch = characters.OrderByDescending(x => x.IsAlive).ThenByDescending(x => x.Health)
				.ThenByDescending(x => x.BaseHealth);
			StringBuilder sb = new StringBuilder();
			foreach (var VARIABLE in ch)
			{
				string status=null;
				if (VARIABLE.IsAlive==true)
				{
					status = "Alive";
				}
				else
				{
					status = "Dead";
				}

				sb.AppendLine($"{VARIABLE.Name} - HP: {VARIABLE.Health}/{VARIABLE.BaseHealth}, AP: {VARIABLE.Armor}/{VARIABLE.BaseArmor}, Status: {status}");
			}

			return sb.ToString().TrimEnd();
		}

		public string Attack(string[] args)
		{
		//	•	attackerName – string
		//		•	receiverName – string
		string attakerName = args[0];
		string receiverName = args[1];
		Character atacker = characters.FirstOrDefault(x => x.Name == attakerName);
		Character receiver = characters.FirstOrDefault(x => x.Name == receiverName);
		if (atacker==null)
		{
			throw new ArgumentException( $"Character {attakerName} not found!");
		}
		if (receiver==null)
		{
			throw new ArgumentException( $"Character {receiverName} not found!");
		}

		if (atacker.GetType().Name=="Priest")
		{
			throw new ArgumentException($"{atacker.Name} cannot attack!");
		}

		StringBuilder sb = new StringBuilder();
	
		Warrior w = atacker as Warrior;
		w.Attack(receiver);

			sb.AppendLine($"{atacker.Name} attacks {receiverName} for {atacker.AbilityPoints} hit points! {receiverName} has {receiver.Health}/{receiver.BaseHealth} HP and {receiver.Armor}/{receiver.BaseArmor} AP left!");

			if (receiver.IsAlive==false)
		{
			sb.AppendLine($"{receiver.Name} is dead!");
		}

		return sb.ToString().TrimEnd();
		}

		public string Heal(string[] args)
		{
			//•	healerName – a string
			//	•	healingReceiverName – string

			string healerName = args[0];
			string healingGuyName = args[1];
			Character healer = characters.FirstOrDefault(x => x.Name == healerName);
			Character healingGuy = characters.FirstOrDefault(x => x.Name == healingGuyName);
			if (healer==null)
			{
				throw new ArgumentException($"Character {healerName} not found!");
			}
			if (healingGuy==null)
			{
				throw new ArgumentException($"Character {healingGuyName} not found!");
			}

			if (healer.GetType().Name=="Warrior")
			{
				throw new ArgumentException($"{healerName} cannot heal!");
			}

			StringBuilder sb = new StringBuilder();
			Priest p = healer as  Priest;
			p.Heal(healingGuy);
			sb.AppendLine($"{healer.Name} heals {healingGuy.Name} for {healer.AbilityPoints}! {healingGuy.Name} has {healingGuy.Health} health now!");
			return sb.ToString().TrimEnd();
		}
	}
}
