using System.Collections.Generic;
using NUnit.Framework;

namespace Computers.Tests
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {

        }

        [Test]
        public void AddCompNull()
        {
            ComputerManager cm = new ComputerManager();
            Computer comp = null;
            Assert.That(() => { cm.AddComputer(comp); },
                Throws.ArgumentNullException.With.Message.EqualTo("Can not be null! (Parameter 'computer')"));
        }

        [Test]
        public void AddCompWhoContaains()
        {
            ComputerManager cm = new ComputerManager();
            Computer comp = new Computer("A", "B", 1);
            cm.AddComputer(comp);
            Computer secondComp = new Computer("A", "B", 1);
            Assert.That(() => { cm.AddComputer(secondComp); },
                Throws.ArgumentException.With.Message.EqualTo("This computer already exists."));

        }

        [Test]
        public void NullVaribleMGetRemove()
        {
            ComputerManager cm = new ComputerManager();

            Assert.That(() => { cm.RemoveComputer(null, null); },
                Throws.ArgumentNullException.With.Message.EqualTo("Can not be null! (Parameter 'manufacturer')"));
        }

        [Test]
        public void NullVaribleModelRemove()
        {
            ComputerManager cm = new ComputerManager();

            Assert.That(() => { cm.RemoveComputer("dsd", null); },
                Throws.ArgumentNullException.With.Message.EqualTo("Can not be null! (Parameter 'model')"));
        }
        [Test]
        public void RemoveWithNotContainsItem()
        {
            ComputerManager cm = new ComputerManager();

            Assert.That(() => { cm.RemoveComputer("dsd", "null"); },
                Throws.ArgumentException.With.Message.EqualTo("There is no computer with this manufacturer and model."));
        }

        [Test]
        public void RemoveComp()
        {
            ComputerManager cm = new ComputerManager();
            Computer comp = new Computer("A", "B", 1);
            cm.AddComputer(comp);
            Assert.That(cm.RemoveComputer("A","B"),Is.EqualTo(comp));

        }
        [Test]
        public void NullVaribleMGetPC()
        {
            ComputerManager cm = new ComputerManager();

            Assert.That(() => { cm.GetComputer(null, null); },
                Throws.ArgumentNullException.With.Message.EqualTo("Can not be null! (Parameter 'manufacturer')"));
        }

        [Test]
        public void NullVaribleModelPC()
        {
            ComputerManager cm = new ComputerManager();

            Assert.That(() => { cm.GetComputer("dsd", null); },
                Throws.ArgumentNullException.With.Message.EqualTo("Can not be null! (Parameter 'model')"));
        }
        [Test]
        public void GetPCWithNotContainsItem()
        {
            ComputerManager cm = new ComputerManager();

            Assert.That(() => { cm.GetComputer("dsd", "null"); },
                Throws.ArgumentException.With.Message.EqualTo("There is no computer with this manufacturer and model."));
        }
        [Test]
        public void GetPC()
        {
            ComputerManager cm = new ComputerManager();
            Computer comp = new Computer("A", "C", 4);
            cm.AddComputer(comp);
            Assert.That(cm.RemoveComputer("A","C"),Is.EqualTo(comp));
        }

        [Test]
        public void GetComputersByManufacturerNull()
        {
            ComputerManager cm = new ComputerManager();
            Assert.That(() => { cm.GetComputersByManufacturer(null); },
                Throws.ArgumentNullException.With.Message.EqualTo("Can not be null! (Parameter 'manufacturer')"));
        }
        [Test]
        public void  GetColectio ()
        {
            ComputerManager cm = new ComputerManager();
            Computer comp = new Computer("A", "C", 4);
            cm.AddComputer(comp);
            ICollection<Computer> c = new List<Computer>();  
            c.Add(comp);
            Assert.That(cm.GetComputersByManufacturer("A"),Is.EqualTo(c));
        }

        [Test]
        public void GetCount()
        {
            ComputerManager cm = new ComputerManager();
            Computer comp = new Computer("A", "C", 4);
            cm.AddComputer(comp);
            Assert.That(cm.Count,Is.EqualTo(1));

        }
        [Test]
        public void GetPCs()
        {
            ComputerManager cm = new ComputerManager();
            Computer comp = new Computer("A", "C", 4);
            cm.AddComputer(comp);
            ICollection<Computer> c = new List<Computer>(); 
            c.Add(comp);
            Assert.That(cm.Computers,Is.EqualTo(c));

        }
        [Test]
        public void PC()
        {
           
            Computer comp = new Computer("A", "C", 4);
         
            
            Assert.That( comp.Manufacturer,Is.EqualTo("A"));
            Assert.That( comp.Model,Is.EqualTo("C"));
            Assert.That( comp.Price,Is.EqualTo(4));
        }
    }
}