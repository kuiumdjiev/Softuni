﻿using System;
using System.Collections.Generic;
using System.Linq;
using WarCroft.Entities.Items;

namespace WarCroft.Entities.Inventory
{
    public abstract class Bag:IBag
    {
        private List<Item> items;

        protected Bag(int capacity)
        {
            items = new List<Item>();

            Capacity = capacity;
        }

        public int Capacity { get; set; } = 100;
        public int Load => items.Sum(x => x.Weight);
        public IReadOnlyCollection<Item> Items => items.AsReadOnly();
        public void AddItem(Item item)
        {
            if (item.Weight+Load>Capacity)
            {
                throw new InvalidOperationException("Bag is full!");
            }
            this.items.Add(item);
        }

        public Item GetItem(string name)
        {
            if (Items.Count==0)
            {
                throw new InvalidOperationException("Bag is empty!");
            }

            if (!Items.Any(x=>x.GetType().Name==name))
            {
                throw new ArgumentException($"No item with name {name} in bag!");
            }

            Item item = Items.FirstOrDefault(x => x.GetType().Name == name);
            items.Remove(item);
            return item;
        }
    }
}