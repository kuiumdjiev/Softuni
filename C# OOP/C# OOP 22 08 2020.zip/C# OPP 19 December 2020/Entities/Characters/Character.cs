﻿using System;
using System.Collections.Generic;
using WarCroft.Constants;
using WarCroft.Entities.Inventory;
using WarCroft.Entities.Items;

namespace WarCroft.Entities.Characters.Contracts
{

    public abstract class Character
    {
        private string name;
        private double baseHealth;
        private double health;
        private double baseArmor;
        private double armor;

        protected Character(string name, double health, double armor, double abilityPoints, Bag bag)
        {
            Name = name;

            baseHealth = health;
            Health = health;

            baseArmor = armor;
            Armor = armor;

            AbilityPoints = abilityPoints;

            Bag = bag;

        }

        public double BaseHealth => baseHealth;
        public double BaseArmor => baseArmor;
        public Bag Bag { get; private set; }
        public string Name
        {
            get => name;
            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException("Name cannot be null or whitespace!");
                }

                name = value;
            }
        }


        public double Health
        {
            get => health;
            set
            {
                if (value < 0 || value > baseHealth)
                {


                }
                else
                {
                    health = value;
                }
            }
        }


        public double Armor
        {
            get => armor;
            set
            {
                if (value < 0)
                {

                }
                else
                {
                    armor = value;
                }
            }
        }

        public double AbilityPoints { get; private set; }
        public bool IsAlive { get; set; } = true;

        public string Dead
        {
            get
            {
                if (IsAlive)
                {
                    return "Alive";
                }

                return "Dead";

            }
        }

        public void TakeDamage(double hitPoints)
        {
            this.EnsureAlive();

            if (hitPoints <= Armor)
            {
                Armor -= hitPoints;
            }
            else
            {
                var pointLeft = hitPoints - Armor;
                Armor = 0;
                Health -= pointLeft;

                if (Health == 0)
                {
                    IsAlive = false;
                }

            }
        }

        public virtual void UseItem(Item item)
        {
            if (IsAlive)
            {
                item.AffectCharacter(this);
            }

        }

        public void EnsureAlive()
        {
            if (!this.IsAlive)
            {
                throw new InvalidOperationException(ExceptionMessages.AffectedCharacterDead);
            }
        }
    }
}