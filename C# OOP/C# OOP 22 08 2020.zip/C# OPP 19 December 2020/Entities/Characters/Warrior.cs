﻿using System;
using WarCroft.Entities.Inventory;

namespace WarCroft.Entities.Characters.Contracts
{
    public class Warrior:Character,IAttacker
    {
        //has 100 Base Health, 50 Base Armor, 40 Ability Points, and a Satchel as a bag.
        public Warrior(string name) 
            : base(name,100,50,40,new Satchel())
        {
        }

        public void Attack(Character character)
        {
            if (this==character)
            {
                throw new InvalidOperationException("Cannot attack self!");

            }
            if (!this.IsAlive||!character.IsAlive)
            {
                throw new InvalidOperationException("Must be alive to perform this action!");
            }
            character.TakeDamage(this.AbilityPoints); 
        }
    }
}