﻿using System;
using WarCroft.Constants;
using WarCroft.Entities.Inventory;

namespace WarCroft.Entities.Characters.Contracts
{
    public class Priest:Character,IHealer
    {
        //50 Base Health, 25 Base Armor, 40 Ability Points, and a Backpack as a bag.
        public Priest(string name) : base(name, 50,25,40,new Backpack())
        {
        }

        public void Heal(Character character)
        {
            
            this.EnsureAlive();
            if (character.IsAlive==false)
            {
                throw new InvalidOperationException(ExceptionMessages.AffectedCharacterDead);
            }
                    character.Health += this.AbilityPoints;
                
            
        }
        
    }
}