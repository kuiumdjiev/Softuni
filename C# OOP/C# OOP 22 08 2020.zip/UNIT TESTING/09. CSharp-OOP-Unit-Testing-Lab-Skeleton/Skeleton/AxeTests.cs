using NUnit.Framework;
using  System;

    [TestFixture]
    public class AxeTests
    {
        [Test]
        //Test if weapon loses durability after each attack
        public void WeaponLosesDurabilityAfterEachAttack()
        {
            Axe axe =new Axe(10, 10);
            Dummy dummy = new Dummy(10, 10);
            axe.Attack(dummy);
            Assert.That(axe.DurabilityPoints,Is.EqualTo(9));
        }

        [Test]
        //Test attacking with a broken weapon
        public void AttackingWithABrokenWeapon()
        {
            Axe axe = new Axe(10, 0);
            Dummy dummy = new Dummy(10, 10);
           
            Assert.That(() =>  axe.Attack(dummy),Throws.InvalidOperationException.With.Message.EqualTo("Axe is broken."));
    }

    }
