﻿using NUnit.Framework;

[TestFixture]
public class DummyTests
{
    [Test]
    //•	Dummy loses health if attacked
    public void 	DummyLosesHealthIfAttacked()
    {
        Axe axe = new Axe(1,5);
        Dummy dummy = new Dummy(10, 10);
        axe.Attack(dummy);
        Assert.That(dummy.Health ,Is.EqualTo(9));
    }

    [Test]
    //•	Dead Dummy throws exception if attacked
    public void	DeadDummyThrowsExceptionIfAttacked()
    {
        Dummy dummy = new Dummy(0, 0);
        Assert.That(()=>dummy.TakeAttack(1), Throws.InvalidOperationException.With.Message.EqualTo("Dummy is dead."));
    }
    [Test]
    //•	Dead Dummy can give XP
    public void 	DeadDummyCanGiveXP()
    {
        Dummy dummy = new Dummy(1, 1);
        dummy.TakeAttack(1);
        Assert.That(dummy.GiveExperience(), Is.EqualTo(1));
    }

    [Test]
    //•	Alive Dummy can't give XP
    public void AliveDummyCantGiveXP()
    {
        Dummy dummy = new Dummy(1, 1);
        Assert.That(() => dummy.GiveExperience(),
            Throws.InvalidOperationException.With.Message.EqualTo("Target is not dead."));
    }

}
