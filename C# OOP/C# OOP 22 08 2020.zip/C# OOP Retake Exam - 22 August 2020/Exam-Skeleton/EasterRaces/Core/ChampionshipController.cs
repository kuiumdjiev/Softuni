﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EasterRaces.Core.Contracts;
using EasterRaces.Models.Cars;
using EasterRaces.Models.Cars.Contracts;
using EasterRaces.Models.Drivers;
using EasterRaces.Models.Drivers.Contracts;
using EasterRaces.Models.Races;
using EasterRaces.Models.Races.Contracts;
using EasterRaces.Repositories;
using EasterRaces.Repositories.Contracts;

namespace EasterRaces.Core
{
    public class ChampionshipController:IChampionshipController
    {
        private IRepository<IDriver> drivers;
        private IRepository<ICar> cars;
        private IRepository<IRace> races;

        public ChampionshipController()
        {
            drivers = new DriverRepository();
            cars = new CarRepository();
            races = new RaceRepository();
;        }
        public string CreateDriver(string driverName)
        {
            if (drivers.GetByName(driverName)!=null)
            {
                throw new ArgumentException($"Driver {driverName} is already created.");
            }

            IDriver driver = new Driver(driverName);
            drivers.Add(driver);
            return $"Driver {driverName} is created.";
        }

        public string CreateCar(string type, string model, int horsePower)
        {
            if (cars.GetByName(model)!=null)
            {
                throw new ArgumentException($"Car {model} is already created.");
            }

            ICar car = null;
            switch (type)
            {
                case "Muscle":
                    car = new MuscleCar(model, horsePower);
                    break;;
                    case "Sports":
                        car = new SportsCar(model, horsePower);
                        break;
               
            }
            cars.Add(car);
            return $"{car.GetType().Name} {model} is created.";
        }

        public string CreateRace(string name, int laps)
        {
            if (races.GetByName(name) != null)
            {
                throw new ArgumentException($"Race {name} is already create.");
            }

            IRace race = new Race(name, laps);
races.Add(race);
            return   $"Race {name} is created.";
        }

        public string AddDriverToRace(string raceName, string driverName)
        {
            if (races.GetByName(raceName)==null)
            {
                throw new InvalidOperationException($"Race {raceName} could not be found.");
            }

            if (drivers.GetByName(driverName)==null)
            {
                throw new InvalidOperationException(	$"Driver {driverName} could not be found.");
            }

            IDriver driver = drivers.GetByName(driverName);
            IRace race = races.GetByName(raceName);
            race.AddDriver(driver);
            drivers.Remove(driver);
            return  $"Driver {driverName} added in {raceName} race.";
        }

        public string AddCarToDriver(string driverName, string carModel)
        {
            if (drivers.GetByName(driverName)==null)
            {
                throw new InvalidOperationException($"Driver {driverName} could not be found.");
            }
            if (cars.GetByName(carModel)==null)
            {
                throw new InvalidOperationException($"Car {carModel} could not be found.");
            }

            IDriver driver = drivers.GetByName(driverName);
            ICar car = cars.GetByName(carModel);
            driver.AddCar(car);
            cars.Remove(car);
            return  $"Driver {driverName} received car {carModel}.";
            
        }

        public string StartRace(string raceName)
        {
            if (races.GetByName(raceName)==null)
            {
                throw new  InvalidOperationException(	$"Race {raceName} could not be found.");
            }

            IRace race = races.GetByName(raceName);
            if (race.Drivers.Count<3)
            {
                throw new InvalidOperationException(	$"Race {raceName} cannot start with less than 3 participants.");
            }

            var r = race.Drivers.OrderByDescending(x=>x.Car.CalculateRacePoints(race.Laps)).ToArray();
            StringBuilder sb = new StringBuilder();
            r[0].WinRace();
            sb.AppendLine(	$"Driver {r[0].Name} wins {race.Name} race.");
            sb.AppendLine($"Driver {r[1].Name} is second in {race.Name} race.");
            sb.AppendLine($"Driver {r[2].Name} is third in {race.Name} race.");
            races.Remove(race);
            return sb.ToString().TrimEnd();
        }
    }
}