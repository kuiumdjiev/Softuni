﻿using System;
using System.Collections.Generic;
using System.Linq;
using FootballTeamGenerator;

namespace Football_Team_Generator
{
    public class Team
    {
        private string name;
        public Team(string name)
        {
            Name = name;
            Players = new List<Player>();
           
        }

        public string Name
        {
            get => name;
            private set
            {
                Check.ChekerName(value);
                name = value;
            }
        }

        public List<Player> Players { get; set; }

        public void Remove(string name)
        {
            Player player = Players.FirstOrDefault(x => x.Name.ToString() == name.ToString());
            if (player==null)
            {
                throw new ArgumentException($"Player {name} is not in {this.Name} team.");
            }
            Players.Remove(player);
        }

        public void Add(Player player)
        {
            Players.Add(player);
        }

        public int Rating =>(int)Math.Round(Players.Sum(x=>x.Skills)/Players.Count);
        public override string ToString()
        {
           
            int r= (Rating>0)?Rating:0;
            return $"{Name} - {r}";
        }
    }
}