﻿using FootballTeamGenerator;

namespace Football_Team_Generator
{
    public class Player
    {
        private string name;
       
        public Player(string name,Stats stats)
        {
            Name = name;
            Stats = stats;
        }

        public string Name
        {
            get => name;
            private set
            {
               Check.ChekerName(value);

                name = value;
            }
        }
        public Stats Stats { get; set; }

        public double Skills => this.Stats.Average();
    }
}