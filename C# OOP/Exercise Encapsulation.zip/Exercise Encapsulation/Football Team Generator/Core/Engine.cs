﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Football_Team_Generator
{
    public class Engine
    {
        public Engine()
        {
            List<Team> teams = new List<Team>();
            string comands = string.Empty;
            while ((comands = Console.ReadLine()) != "END")
            {
                try
                {
                    string[] info = comands.Split(';', StringSplitOptions.RemoveEmptyEntries).ToArray();
                    switch (info[0])
                    {
                        case "Team":
                            string nameTeam = info[1];
                            Team team = new Team(nameTeam);
                            teams.Add(team);
                            break;
                            ;
                        case "Add":
                            //add player
                            string name = info[1];
                            Team teamAdd = teams.FirstOrDefault(x => x.Name == name);
                            if (teamAdd==null)
                            {
                                Console.WriteLine($"Team {name} does not exist.");
                                continue;
                            }
                            
                            string playerName = info[2];
                            int endurance = int.Parse(info[3]);
                            int sprint = int.Parse(info[4]);
                            int dribble = int.Parse(info[5]);
                            int passing = int.Parse(info[6]);
                            int shooting = int.Parse(info[7]);
                            Stats stats = new Stats(endurance, sprint, dribble, passing, shooting);
                            Player player = new Player(playerName, stats);
                            
                            teams[teams.IndexOf(teamAdd)].Add(player);
                            break;
                        case "Remove":
                            string removeNameTeam = info[1];
                            string removeNamePlayer = info[2];
                            Team teamRemove = teams.FirstOrDefault(x => x.Name == removeNameTeam);
                            teams[teams.IndexOf(teamRemove)].Remove(removeNamePlayer);
                            break;
                        case "Rating":
                            string rating = info[1];
                            Team teamRating = teams.FirstOrDefault(x => x.Name == rating);
                            if (teamRating==null)
                            {
                               
                                Console.WriteLine($"Team {rating} does not exist.");
                                continue;
                            }
                            Console.WriteLine(teamRating);
                            break;
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }
        }
    }
}