﻿using System;

namespace FootballTeamGenerator
{
    public static class Check
    {
        public  static void Cheker(int value, string name)
        {
            if (value>100||value<0)
            {
                throw new ArgumentException($"{name} should be between 0 and 100.");
            }
        }
        public static void ChekerName( string name)
        {
            if (string.IsNullOrEmpty(name)||string.IsNullOrWhiteSpace(name))
            {
                throw new ArgumentException($"A {0} should not be empty.");
            }
        }
    }
}