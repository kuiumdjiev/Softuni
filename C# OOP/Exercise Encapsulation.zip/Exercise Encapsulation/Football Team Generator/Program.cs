﻿using System;
using System.Collections.Generic;

namespace Football_Team_Generator
{
   public class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
        }
        
    }
}
