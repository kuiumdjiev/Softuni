﻿using System;

namespace ClassBoxData
{
    public class Box
    {
        private double lenght;
        private double width;
        private double height;

        public Box(double lenght, double widht, double height)
        {
            Lenght = lenght;
            Width = widht;
            Height = height;
        }

        public double Lenght
        {
            get => lenght;
            private set
            {
                IsCorect(value, nameof(Lenght));
                lenght = value;
            }
        }

        public double Width
        {
            get => width;
            private set
            {
                IsCorect(value, nameof(Width));
                width = value;
            }
        }

        public double Height
        {
            get => height;
            private set
            {
                IsCorect(value, nameof(height));
                height = value;
            }
        }

        private double Volume()
        {
            return Lenght * Height * Width;
        }

        private double LateralSurfaceArea()
        {
            return Lenght * 2 * Height + 2 * Width * Height;
        }

        private double SurfaceArea()
        {
            return 2 * Lenght * Width + 2 * Lenght * Height + (2 * Width * height);
        }

        private void IsCorect(double value, string name)
        {
            if (value <= 0)
            {
                throw new ArgumentException($"{name} cannot be zero or negative.");
            }
        }

        public override string ToString()
        {
            return $"Surface Area - {SurfaceArea():F2}" + Environment.NewLine +
                   $"Lateral Surface Area - {LateralSurfaceArea():F2}" + Environment.NewLine +
                   $"Volume - {Volume():F2}";
        }
    }
}