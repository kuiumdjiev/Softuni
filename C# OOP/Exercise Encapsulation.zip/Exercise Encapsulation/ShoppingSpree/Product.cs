﻿namespace ShoppingSpree
{
    public class Product
    {
        private string name;
        private decimal price;

        public Product(string name, decimal price)
        {
            Name = name;
            Price = price;
        }

        public string Name
        {
            get => name;
            private set
            {
                Cheker.CheckName(value);
                name = value;
            }
        }

        public decimal Price
        {
            get => price;
            private set
            {
                Cheker.CheckPrice(price);
                price = value;
            }
        }

        public override string ToString()
        {
            return Name;
        }
    }

}


