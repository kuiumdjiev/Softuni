﻿using System;
using System.Collections.Generic;

namespace ShoppingSpree
{
    public class Person
    {
        private string name;
        private decimal money;


        public Person(string name, decimal money)
        {
            Name = name;
            Money = money;
            Products = new List<Product>();
        }

        public List<Product> Products { get; set; }
        public string Name
        {
            get => name;
            private set
            {
                Cheker.CheckName(value);
                name = value;
            }
        }

        public decimal Money
        {
            get => money;
             set
            {
                Cheker.CheckPrice(value);
                money = value;
            }
        }

        public void Add(Product product)
        {
            if (product.Price>Money)
            {
                throw new ArgumentException($"{Name} can't afford {product.Name}");
            }
            Money -= product.Price;
            this.Products.Add(product);
            Console.WriteLine($"{Name} bought {product.Name}");
        }

        public override string ToString()
        {
            if (Products.Count==0)
            {
                return $"{Name} - Nothing bought";
            }
           
            return $"{Name} - {string.Join(", ",Products)}";
        }
    }
}