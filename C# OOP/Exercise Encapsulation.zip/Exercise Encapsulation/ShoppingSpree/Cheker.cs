﻿using System;

namespace ShoppingSpree
{
    public static class Cheker
    {
        public static void CheckName(string name)
        {
            if (string.IsNullOrEmpty(name))
            {
                throw new ArgumentException($"{name} cannot be empty");
            }
        }
        public static void CheckPrice( decimal price)
        {
            if (price<0)
            {
                throw new ArgumentException($"{price} cannot be negative");
            }
        }
    }
}