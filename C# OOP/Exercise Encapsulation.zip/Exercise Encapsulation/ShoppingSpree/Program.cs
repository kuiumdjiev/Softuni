﻿using System;
using System.Collections.Generic;
using  System.Linq;

namespace ShoppingSpree
{
    public class StartUp
    {
        static void Main(string[] args)
        {
         Dictionary<string,Person> persons = TakePerson();
         Dictionary<string, Product> products = TakeFood();
         string comand = string.Empty;
         while ((comand=Console.ReadLine())!="END")
         {
             try
             {
                 string[] info = comand.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                 string person = info[0];
                 string product = info[1];
                 persons[person].Add(products[product]);
                }
             catch (Exception e)
             {
                 Console.WriteLine(e.Message);
                
             }
           
         }

         foreach (var VARIABLE in persons)
         {
             Console.WriteLine(VARIABLE.Value);
         }
        }
        private static Dictionary<string, Product> TakeFood()
        {
            Dictionary<string, Product> dsP = new Dictionary<string, Product>();
            string[] inputInfo = Console.ReadLine().Split(';',StringSplitOptions.RemoveEmptyEntries);
            foreach (var VARIABLE in inputInfo)
            {
                string[] data = VARIABLE.Split('=');
                string name = data[0];
                decimal money = decimal.Parse(data[1]);
                dsP.Add(name, new Product(name, money));
            }

            return dsP;
        }
        private static Dictionary<string,Person> TakePerson()
        {
            Dictionary<string, Person> ds = new Dictionary<string, Person>();
            string[] inputInfo = Console.ReadLine().Split(';');
            foreach (var VARIABLE in inputInfo)
            {
                string[] data = VARIABLE.Split('=');
                string name = data[0];
                decimal money = decimal.Parse(data[1]);
                ds.Add(name,new Person(name,money));
            }

            return ds;
        }
    }
}