﻿namespace PizzaCalories
{
    public class Dough
    {
        private string floorType;
        private string bakingType;
        private double gramsType;

        public Dough(string floor,string baking,double grams)
        {
            Floor = floor;
            Baking = baking;
            Grams = grams;

        }

        public string Floor
        {
            get => floorType;
            private set
            {
                if (!Constant.DefaultFlour.ContainsKey(value.ToLower()))
                {
                    DoError.Error(Constant.invalidDouth);
                }

                floorType = value.ToLower();
            }
        }

        public string Baking
        {
            get => bakingType;
            private set
            {
                if (!Constant.DefaultBaking.ContainsKey(value.ToLower()))
                {
              DoError.Error(Constant.invalidDouth);      
                }

                bakingType = value.ToLower();


            }
        }

        public double Grams
        {
            get => gramsType;
            private set
            {
                if (value<Constant.minW&&value>Constant.maxW)
                {
                    DoError.Error(Constant.outOfRangeDouth);
                }

                gramsType = value;
            }
        }

        public double Calories => CalculateCal;

        private double CalculateCal => (Constant.caloriesPerGram * Grams) *Constant.DefaultFlour[Floor]  * Constant.DefaultBaking[Baking]-10;

    }
}