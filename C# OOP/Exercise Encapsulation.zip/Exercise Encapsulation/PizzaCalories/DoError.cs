﻿using System;

namespace PizzaCalories
{
   static public class DoError
    {
        public static void Error (string error)
        {
            throw new ArgumentException(error);
        }
    }
}