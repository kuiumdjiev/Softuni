﻿using System;

namespace PizzaCalories
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Pizza pizza;
            string comand = Console.ReadLine();
            string[] info = comand.Split(' ', StringSplitOptions.RemoveEmptyEntries);
            string name = info[1];
            string[] d = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries);
            string floor = d[1];
            string baking = d[2];
            double grams = double.Parse(d[3]);
            Dough dough = new Dough(floor, baking,grams);
            pizza = new Pizza(name, dough);
            while ((comand = Console.ReadLine()) != "END")
            {
                string[] arr = comand.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                try
                {
                    string toping = arr[1];
                    double gramsT = double.Parse(arr[2]);
                    Topping topping = new Topping(toping, gramsT);
                    pizza.AddToping(topping);
                    
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    return;
                }
            }

            Console.WriteLine(pizza);
        }
    }
}
