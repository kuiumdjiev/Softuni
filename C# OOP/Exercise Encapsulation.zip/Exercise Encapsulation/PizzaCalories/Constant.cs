﻿using System.Collections.Generic;

namespace PizzaCalories
{
   static public class Constant
   {
       public static double caloriesPerGram = 2;
       public static double minW = 1;
       public static double maxW = 200;
       public static double minToping = 1;
       public static double maxToping = 50;
     

       static public readonly Dictionary<string, double> DefaultToping = new Dictionary<string, double>
       {
           { "meat"  ,1.2},
           { "cheese"  ,1.2},
           { "sauce"  ,0.9},
           { "veggies", 0.8}
       };

        static   public readonly Dictionary<string, double> DefaultFlour = new Dictionary<string, double>
        {
            { "white", 1.5},
            { "wholegrain", 1.0}
        };
      static  public readonly Dictionary<string, double> DefaultBaking = new Dictionary<string, double>
        {
            { "crispy", 0.9},
            { "chewy", 1.1},
            { "homemade", 1.0}
        };
        //Erorr
        public const  string invalidDouth=	"Invalid type of dough.";
        public const  string outOfRangeDouth=	"Dough weight should be in the range [1..200].";
    }
}