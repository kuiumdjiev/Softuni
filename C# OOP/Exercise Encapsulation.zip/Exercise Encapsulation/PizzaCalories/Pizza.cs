﻿using System.Collections.Generic;
using System.Linq;

namespace PizzaCalories
{
    public class Pizza
    {
        private string name;
        
      
        public Pizza(string name, Dough dough)
        {
            Toppings = new List<Topping>();
            Name = name;
            Dough = dough;
        }

        public string Name
        {
            get=>name;
            private set
            {
                if (value.Length>15)
                {
                    DoError.Error("Pizza name should be between 1 and 15 symbols.");
                }

                name = value;
            }
        }
        public Dough Dough { get; set; }
        public List<Topping> Toppings { get; set; }

        public void AddToping(Topping topping)
        {
            if (Toppings.Count > 10)
            {
                DoError.Error("Number of toppings should be in range [0..10].");
            }
            Toppings.Add(topping);
        }

        public override string ToString()
        {
            return $"{Name} - {(Dough.Calories+Toppings.Sum(x=>x.Calories)):F2} Calories.";
        }
    }
}