﻿namespace PizzaCalories
{
    public class Topping
    {
     //   grams
     private string topingType;
     private double grams;

     public Topping(string toping,double grams)
     {
         Grams = grams;
         Toping = toping;
     }

     private double CalcCalorias => Constant.DefaultToping[Toping] * 2 * Grams;
     public string Toping
     {
         get=>topingType;
         private set
         {
             if (!Constant.DefaultToping.ContainsKey(value.ToLower()))
             {
                 DoError.Error(	$"Cannot place {value} on top of your pizza.");
             }

             topingType = value.ToLower();
         }
     }

     public double Grams
     {
         get=>grams;
         private set
         {
             if (value>Constant.maxToping||value<Constant.minToping)
             {
                 DoError.Error(	$"{Toping} weight should be in the range [1..50].");
             }

             grams = value;
         }

     }

     public double Calories => CalcCalorias;


    }
}