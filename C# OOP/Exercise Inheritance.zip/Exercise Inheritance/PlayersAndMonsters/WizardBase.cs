﻿namespace PlayersAndMonsters
{
    public class WizardBase
    {
    }
}