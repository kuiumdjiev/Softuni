﻿namespace NeedForSpeed
{
    public class Vehicle
    {
      private  const  double DefautFuelConsumption= 1.25;

      public Vehicle(int horsePower , double fuel)
      {
          Fuel = fuel;
          HorsePower = horsePower;
      }

        public double Fuel   { get; set; }

        public int HorsePower { get; set; }

        public virtual double FuelConsumption => DefautFuelConsumption;


        public virtual void Drive(double kilometers)
        {
            Fuel -= kilometers * FuelConsumption;
        }
    }
}