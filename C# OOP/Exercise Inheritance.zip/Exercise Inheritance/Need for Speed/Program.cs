﻿using System;

namespace Need_for_Speed
{
  public  class StartUp
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
