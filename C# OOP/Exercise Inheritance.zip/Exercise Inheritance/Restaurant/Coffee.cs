﻿namespace Restaurant
{
    public class Coffee:HotBeverage
    {
        private const double DefautMilliliters = 50;
        private const decimal DefautPrice = 3.50M;
        public Coffee(string name,double caffeine) : base(name, DefautPrice,DefautMilliliters)
        {
            Caffeine = caffeine;
        }

        public double Caffeine { get; set; }
    }
}