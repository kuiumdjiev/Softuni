﻿using System;
using System.Linq;

namespace Animals
{
    public class StartUp

    {
    static void Main(string[] args)
    {
        string comand = string.Empty;
        while ((comand = Console.ReadLine()) != "Beast!")
        {
            string[] arr = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries).ToArray();
            string name = arr[0];
            int age = int.Parse(arr[1]);
            string gender = arr[2];
            if (age < 0 || string.IsNullOrEmpty(name) || string.IsNullOrEmpty((gender)) || string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace((gender)))
            {
                Console.WriteLine("Invalid input!");
                continue;
            }

            switch (comand)
            {
                case "Dog":
                    var dog = new Dog(name, age, gender);
                    Console.WriteLine(dog);
                    Console.WriteLine(dog.ProduceSound());
                    break;
                case "Cat":
                    var cat = new Cat(name, age, gender);
                    Console.WriteLine(cat);
                    Console.WriteLine(cat.ProduceSound());
                    break;
                case "Frog":
                    var frog = new Cat(name, age, gender);
                    Console.WriteLine(frog);
                    Console.WriteLine(frog.ProduceSound());
                    break;
                case "Kittens":
                    var kittens = new Kitten(name, age);
                    Console.WriteLine(kittens);
                    Console.WriteLine(kittens.ProduceSound());
                    break;
                case "Tomcat":
                    var tom = new Tomcat(name, age);
                    Console.WriteLine(tom);
                    Console.WriteLine(tom.ProduceSound());
                    break;
                default:
                    Console.WriteLine("Invalid input!");
                    
                        break;
            }
        }
    }
    }
}
