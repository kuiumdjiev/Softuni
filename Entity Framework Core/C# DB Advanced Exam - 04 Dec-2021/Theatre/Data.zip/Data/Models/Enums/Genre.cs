﻿namespace Theatre.Data.Models.Enums
{
    public enum Genre
    {
        Drama=0,
        Comedy=1,
        Romance=3,
        Musical=4
    }
}