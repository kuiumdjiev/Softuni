﻿namespace BookShop.DataProcessor.ImportDto
{
    public class ImportAuthorBookModel
    {
        public int? Id { get; set; }
    }
}